import { useComputed, useSignalEffect } from "@preact/signals";
import { useCallback, useEffect, useRef, useState } from "preact/compat";

import { useAvatarConfig } from "../contexts/avatar-config";
import { useConversation } from "../contexts/conversation";
import { Orb } from "../orb/Orb";
import { clsx } from "clsx";

const SIZE_CLASSES = {
  xs: "w-7 h-7",
  sm: "w-9 h-9",
  header: "w-9 h-9",
  md: "w-40 h-40",
  lg: "w-48 h-48",
};

interface AvatarProps {
  size?: keyof typeof SIZE_CLASSES;
  className?: string;
  backgroundClassName?: string;
  imageClassName?: string;
  backgroundColor?: string;
  imageBackgroundColor?: string;
  imageScale?: number;
}

export function Avatar({
  size = "sm",
  className,
  backgroundClassName,
  imageClassName,
  backgroundColor,
  imageBackgroundColor,
  imageScale = 1,
}: AvatarProps) {
  const { getInputVolume, getOutputVolume, isSpeaking, isDisconnected } =
    useConversation();
  const { config } = useAvatarConfig();
  const backgroundRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useSignalEffect(() => {
    const background = backgroundRef.current;
    const image = imageRef.current;
    if (!background || !image) {
      return;
    }

    if (isDisconnected.value) {
      background.style.transform = "";
      image.style.transform =
        imageScale === 1 ? "" : `scale(${imageScale})`;

      return;
    }

    let id: number;
    function draw() {
      const backgroundNode = backgroundRef.current;
      const imageNode = imageRef.current;
      if (!backgroundNode || !imageNode) {
        return;
      }

      const inputVolume = getInputVolume();
      const outputVolume = getOutputVolume();

      const inputScale = isSpeaking.peek() ? 1 : 1 - inputVolume * 0.4;
      const outputScale = !isSpeaking.peek() ? 1 : 1 + outputVolume * 0.4;

      backgroundNode.style.transform = `scale(${outputScale})`;
      imageNode.style.transform = `scale(${inputScale * imageScale})`;

      id = requestAnimationFrame(draw);
    }
    draw();

    return () => {
      cancelAnimationFrame(id);
    };
  });

  const style = useComputed(() => ({
    backgroundColor: imageBackgroundColor,
    backgroundImage:
      config.value.type === "image"
        ? `url(${config.value.url})`
        : config.value.type === "url"
          ? `url(${config.value.custom_url})`
          : undefined,
  }));

  return (
    <div className={clsx("relative shrink-0", SIZE_CLASSES[size], className)}>
      <div
        ref={backgroundRef}
        style={backgroundColor ? { backgroundColor } : undefined}
        className={clsx(
          "absolute inset-0 rounded-full bg-base-border",
          backgroundClassName
        )}
      />
      <div
        ref={imageRef}
        style={style}
        className={clsx(
          "absolute inset-0 rounded-full overflow-hidden bg-base bg-cover bg-center",
          imageClassName
        )}
      >
        {config.value.type === "orb" && (
          <OrbCanvas
            color1={config.value.color_1}
            color2={config.value.color_2}
          />
        )}
      </div>
    </div>
  );
}

function OrbCanvas({ color1, color2 }: { color1: string; color2: string }) {
  const { canvasUrl } = useAvatarConfig();
  const [orb, setOrb] = useState<Orb | null>(null);
  useEffect(() => {
    if (orb) {
      orb.updateColors(color1, color2);
      orb.render();
      canvasUrl.value = orb.toDataURL();
    }
  }, [orb, color1, color2]);

  const setupOrb = useCallback(
    (canvas: HTMLCanvasElement | null) => {
      if (canvas) {
        const reference = new Orb(canvas);
        setOrb(reference);
        return () => reference.dispose();
      } else {
        setOrb(null);
      }
    },
    [setOrb]
  );

  return <canvas className="w-full h-full" ref={setupOrb} />;
}
