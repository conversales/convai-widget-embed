# @elevenlabs/convai-widget-embed

## 0.13.1

### Patch Changes

- Pin `@radix-ui/react-slot` to 1.2.3 to fix embed build warning about undefined React `use()` on Preact compat.

## 0.13.0

### Minor Changes

- 2b8e66f: Add product cart checkout flow with confirmation card, Shopify MCP cart sync, mobile fullscreen layout, and production widget history API. Fix checkout link so it no longer resets the active chat session.

## 0.12.14

- Republish the embed bundle with the updated lead-capture gating and centered lead card UI.

## 0.12.6

- Republish the embed bundle with the updated Conversales header, footer, and sheet sizing.

## 0.12.5

- Republish the embed bundle with the dual custom-element registration fix used by the widget core package.

## 0.12.4

## 0.12.3

## 0.12.2

## 0.12.1

## 0.12.0

## 0.11.7

## 0.11.6

## 0.11.5

## 0.11.4

## 0.11.3

## 0.11.2

## 0.11.1

## 0.11.0

### Minor Changes

- e656158: Auto-select widget language from localStorage history and browser language preferences.

  When no explicit `language` attribute is set, the widget now resolves the initial language by checking (in order):
  1. The `language` attribute on the widget element
  2. The last language the user selected (persisted in localStorage)
  3. The user's browser language preferences (`navigator.languages`)
  4. The agent's default language

  Language selections are persisted to localStorage so returning users see their preferred language automatically.

## 0.10.6

## 0.10.5

## 0.10.4

## 0.10.3

## 0.10.2

## 0.10.1

## 0.10.1-next.0

## 0.10.0

## 0.9.1

### Patch Changes

- 6946723: Fix style does not show correctly in safari.

## 0.9.0

### Minor Changes

- 6846068: Ability to show agent tool usage status
- 6846068: New agent status badge for long tool call

### Patch Changes

- a71950d: strip emotion tag

## 0.8.2

## 0.0.0-beta.0

## 0.8.1

### Patch Changes

- c96feb1: Reset microphone mute state when call ends to prevent UI/audio desync on subsequent calls

## 0.8.0

### Minor Changes

- 75b01f2: Fix styling issue in shadow root

## 0.7.0

### Minor Changes

- 29ef161: Allow the widget to be dismissable via an optional parameter.
